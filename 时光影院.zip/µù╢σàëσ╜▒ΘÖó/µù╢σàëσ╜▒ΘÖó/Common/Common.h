//
//  Common.h
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#ifndef Common_h
#define Common_h

#define KScreenWidth [UIScreen mainScreen].bounds.size.width

#define KScreenHeight [UIScreen mainScreen].bounds.size.height

#import "RequestData.h"

#import "UIImageView+WebCache.h"

#define top250 @"top250.json"

#define movie_detail @"movie_detail.json"

#define movie_comment @"movie_comment.json"

#define image_list @"image_list.json"


#endif /* Common_h */

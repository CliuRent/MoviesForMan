//
//  RequestData.h
//  时光影院
//
//  Created by admin on 16/8/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestData : NSObject

+(instancetype)requsetDataWithFileName:(NSString *)fileName;

@end

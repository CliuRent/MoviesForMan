//
//  TabBarItem.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TabBarItem.h"

@implementation TabBarItem

-(instancetype)initWithFrame:(CGRect)frame withImageName:(NSString *)imageName withTitle:(NSString *)title
{
    self = [super initWithFrame:frame];
    if(self != nil)
    {
        //创建背景视图
        UIImageView *bgImageView = [[UIImageView alloc]initWithFrame:CGRectMake((frame.size.width - 20)/2, 5, 20, 20)];
        
        //视图图片
        bgImageView.image = [UIImage imageNamed:imageName];
        
        //填充方式 不发生形变
        bgImageView.contentMode = UIViewContentModeScaleAspectFit;
        
        //添加
        [self addSubview:bgImageView];
        
        CGFloat maxy = CGRectGetMaxY(bgImageView.frame);
        
        //创建标题视图
        UILabel *titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, maxy,frame.size.width, 20)];
        titleLable.text = title;
        titleLable.textColor = [UIColor whiteColor];
        titleLable.textAlignment = NSTextAlignmentCenter;
        titleLable.font = [UIFont systemFontOfSize:13];
        
        //添加
        [self addSubview:titleLable];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

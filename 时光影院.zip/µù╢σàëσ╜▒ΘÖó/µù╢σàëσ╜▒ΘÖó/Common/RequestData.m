//
//  RequestData.m
//  时光影院
//
//  Created by admin on 16/8/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "RequestData.h"

@implementation RequestData

//方法实现
+(instancetype)requsetDataWithFileName:(NSString *)fileName
{
    NSString *filePath = [[NSBundle mainBundle]pathForResource:fileName ofType:nil];
    NSData *data  = [NSData dataWithContentsOfFile:filePath];
    
    //解析json文件
    id anyObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:NULL];
    return anyObject;
}

@end

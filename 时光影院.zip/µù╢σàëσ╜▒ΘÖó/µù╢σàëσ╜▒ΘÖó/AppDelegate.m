//
//  AppDelegate.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "AppDelegate.h"
#import "GuideController.h"
#import "BaseTabBarController.h"
#import "LaunchController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
//    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
//    self.window.backgroundColor = [UIColor clearColor];
//    [self.window makeKeyAndVisible];
//
//    
//    
//    
//    Ha *tabBarController = [[Ha alloc]init];
//    
//    self.window.rootViewController = tabBarController;
    
    /*
    BOOL isFirst = YES;
    
    //创建一个plist文件并追加到沙盒文件中
    NSString *filePath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/FirstIn.plist"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    
    //根据key取出Value
    NSNumber *number = [dic objectForKey:@"isFirst"];
    
    isFirst = [number boolValue];
    
    //第一次一定为空
    if(!isFirst)
    {
        NSDictionary *dic = @{@"isFirst" : @YES};
        [dic writeToFile:filePath atomically:YES];
     
        //创建视图控制器
        GuideController *guide = [[GuideController alloc]init];
        self.window.rootViewController = guide;
    }else
    {
//        BaseTabBarController *tabBarController = [[BaseTabBarController alloc]init];
//        
//        self.window.rootViewController = tabBarController;
        
        LaunchController *launch = [[LaunchController alloc]init];
        self.window.rootViewController = launch;
    }
     */
    return YES;
     
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end

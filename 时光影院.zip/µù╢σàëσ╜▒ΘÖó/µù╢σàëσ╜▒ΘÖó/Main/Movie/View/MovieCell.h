//
//  MovieCell.h
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MovieModel;
@class StarView;
@interface MovieCell : UITableViewCell
{
    
    __weak IBOutlet UIImageView *movieImageview;
    
    __weak IBOutlet UILabel *titleLable;    //电影标题
    __weak IBOutlet UILabel *averageLable;  //评分
    __weak IBOutlet UILabel *yearLable;     //年份
    
    __weak IBOutlet StarView *starView;
}
@property(nonatomic,strong)MovieModel *movieModel;

@end

//
//  StarView.m
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "StarView.h"

@implementation StarView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        [self _createSubViews];
    }
    return self;
}

//有XIB文件的情况下，会优先调用次方法
-(void)awakeFromNib
{
    [self _createSubViews];
}

-(void)_createSubViews
{
    //星星图片
    UIImage *yellowImage = [UIImage imageNamed:@"yellow"];
    UIImage *grayImage = [UIImage imageNamed:@"gray"];
    
    //初始化星星视图
    _yellowView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, yellowImage.size.width * 5, grayImage.size.height)];
    //填充背景图片
    _yellowView.backgroundColor = [UIColor colorWithPatternImage:yellowImage];
    
    _grayView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, grayImage.size.width * 5, grayImage.size.height)];
    //以星星为背景颜色
    _grayView.backgroundColor = [UIColor colorWithPatternImage:grayImage];
    
    //添加
    [self addSubview:_grayView];
    [self addSubview:_yellowView];
    
    //原图太小，所以放大原图达到填充效果
    //放大比例
    /*
     星星的宽和高大致相同，且星星宽高会变，所以采用父视图的高作为计算放大比例的除数
     */
    CGFloat scale = self.frame.size.height / yellowImage.size.height;
    
    _yellowView.transform = CGAffineTransformMakeScale(scale, scale);
    _grayView.transform = CGAffineTransformMakeScale(scale, scale);
    
    //放大使星星位置偏移，使用自适应
    CGRect frame1 = _yellowView.frame;
    CGRect frmae2 = _grayView.frame;
    frame1.origin = CGPointZero;
    frmae2.origin = CGPointZero;
    _yellowView.frame = frame1;
    _grayView.frame = frmae2;
    
    //背景色为透明色
    self.backgroundColor = [UIColor clearColor];
}

//保证rating一定存在
-(void)setRating:(CGFloat)rating
{
    //分数比例
    CGFloat scale =     rating / 10.0;
    
    //在放大后的基础上做修改
    CGFloat width = self.frame.size.height / [UIImage imageNamed:@"yellow"].size.height
    * [UIImage imageNamed:@"yellow"].size.width * 5 * scale;
    
    //改变frame
    CGRect frame = _yellowView.frame;
    frame.size.width = width;
    _yellowView.frame = frame;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

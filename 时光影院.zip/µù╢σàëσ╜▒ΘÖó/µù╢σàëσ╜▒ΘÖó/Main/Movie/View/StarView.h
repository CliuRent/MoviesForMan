//
//  StarView.h
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarView : UIView
{
    //金星
    UIView *_yellowView;
    //银星
    UIView *_grayView;
}
@property(nonatomic,assign)CGFloat rating;  //评分
@end

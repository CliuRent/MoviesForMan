//
//  PosterView.h
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PosterCollectionView;
@class IndexCollectionView;

@interface PosterView : UIView

//头视图
@property(nonatomic,strong)UIView *headerView;

//索引海报视图
@property(nonatomic,strong)IndexCollectionView *indexColltion;

//尾部视图
@property(nonatomic,strong)UILabel *footerLabel;

//遮盖视图
@property(nonatomic,strong)UIControl *maskView;

//集合视图
@property(nonatomic,strong)PosterCollectionView *posterCollection;

//数据
@property(nonatomic,strong)NSMutableArray *data;

@end

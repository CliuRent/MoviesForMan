//
//  IndexCell.h
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MovieModel;
@interface IndexCell : UICollectionViewCell

@property(nonatomic,strong)UIImageView *imgView;

@property(nonatomic,strong)MovieModel *movie;

@end

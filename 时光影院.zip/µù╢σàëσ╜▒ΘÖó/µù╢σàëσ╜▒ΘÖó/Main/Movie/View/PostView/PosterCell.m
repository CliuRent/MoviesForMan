//
//  PosterCell.m
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PosterCell.h"
#import "MovieModel.h"
#import "MovieDetailView.h"

@implementation PosterCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //创建图片视图
        [self _loadImageView];
    }
    return self;
}

//创建视图
-(void)_loadImageView
{
    _posterImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.bounds.size.width * 0.95, self.contentView.bounds.size.height * 0.95)];
    _posterImageView.center = self.contentView.center;
    
    [self.contentView addSubview:_posterImageView];

    //从xib文件中读取视图
    
    _detailView = [[[NSBundle mainBundle]loadNibNamed:@"MovieDetailView" owner:self options:nil]lastObject];
    
    _detailView.transform = CGAffineTransformMakeScale(0.95, 0.95);
    
    _detailView.backgroundColor = [UIColor cyanColor];
    
    _detailView.center = self.contentView.center;
        
    [self.contentView insertSubview:_detailView belowSubview:_posterImageView];
}

//确保model存在
-(void)setMovie:(MovieModel *)movie
{
    if(_movie != movie)
    {
        _movie = movie;
        
        NSString *imageName = [movie.images objectForKey:@"large"];
        
        [_posterImageView sd_setImageWithURL:[NSURL URLWithString:imageName] placeholderImage:[UIImage imageNamed:@"pig"]];
        
        _detailView.movie = movie;
    }
}
//翻转方法
-(void)PosterFlip
{
    UIViewAnimationOptions options = _isTurn ? UIViewAnimationOptionTransitionFlipFromLeft : UIViewAnimationOptionTransitionFlipFromRight;
    
    [UIView transitionWithView:self.contentView duration:.2 options:options animations:^{
        //取到子视图
        NSInteger index1 = [self.contentView.subviews indexOfObject:_posterImageView];
        NSInteger index2 = [self.contentView.subviews indexOfObject:_detailView];
        
        //实现翻转
        [self.contentView exchangeSubviewAtIndex:index1 withSubviewAtIndex:index2];
    } completion:NULL];
    
    _isTurn = !_isTurn;
}

@end

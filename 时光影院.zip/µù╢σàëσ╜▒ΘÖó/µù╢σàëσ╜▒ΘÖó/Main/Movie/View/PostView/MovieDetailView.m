//
//  MovieDetailView.m
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "MovieDetailView.h"
#import "MovieModel.h"
#import "StarView.h"

@implementation MovieDetailView

//确保数据一定存在
-(void)setMovie:(MovieModel *)movie
{
    if(_movie != movie)
    {
        _movie = movie;
        
        //填充数据
        
        NSString *imgName = [movie.images objectForKey:@"medium"];
        [_imgView sd_setImageWithURL:[NSURL URLWithString:imgName] placeholderImage:[UIImage imageNamed:@"pig"]];
        
        //标题
        _titleLabel.numberOfLines = 0;
        [_titleLabel sizeToFit];
        _titleLabel.text = [NSString stringWithFormat:@"中文名:%@",movie.title];
        
        //原标题
        _originalLabel.numberOfLines = 0;
        [_originalLabel sizeToFit];
        _originalLabel.text = [NSString stringWithFormat:@"英文名:%@",movie.original_title];
        
        //年份
        [yearLabel sizeToFit];
        yearLabel.text = [NSString stringWithFormat:@"年份:%@",movie.year];
        
        //星星
        _starView.rating = [movie.average floatValue];
        
        //评分
        ratingLabel.text = [NSString stringWithFormat:@"%.1f",movie.average.floatValue];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

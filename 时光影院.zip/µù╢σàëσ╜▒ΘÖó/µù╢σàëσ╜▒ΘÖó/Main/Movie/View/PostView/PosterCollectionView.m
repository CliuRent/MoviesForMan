//
//  PosterCollectionView.m
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PosterCollectionView.h"
#import "PosterCell.h"

@implementation PosterCollectionView

//覆写inintWithFrame方法


-(instancetype)initWithFrame:(CGRect)frame
{
    //创建布局对象
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    
    //设置间隙
    flowLayout.minimumLineSpacing = 0;
    
    //设置滑动方向
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    if(self = [super initWithFrame:frame collectionViewLayout:flowLayout])
    {
        //设置代理
        self.delegate = self;
        self.dataSource = self;
        
        //滚动条
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        
        //注册单元格
        [self registerClass:[PosterCell class] forCellWithReuseIdentifier:@"cell"];
        
        //减速度
        self.decelerationRate = UIScrollViewDecelerationRateFast;
        
    }
    return self;
}

#pragma mark - 数据源及代理方法 

//单元格size
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(_cellWidth, CGRectGetHeight(self.frame));
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _data.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //复用
    PosterCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    
    //传递数据
    cell.movie = _data[indexPath.item];
    return cell;
}

//单元格偏移
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    CGFloat offsetx = (CGRectGetWidth(self.frame) - _cellWidth)/2;
    return UIEdgeInsetsMake(0, offsetx, 0, offsetx);
}

//分页效果的制作
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    int index = (targetContentOffset->x + _cellWidth/2) / _cellWidth;

    //设置回去
    targetContentOffset->x = index * _cellWidth;

    //记录下标
    self.currentIndex = index;
}

//单元格点击方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(_currentIndex == indexPath.item)
    {
        //取到点击的单元格
        PosterCell *cell = (PosterCell *)[collectionView cellForItemAtIndexPath:indexPath];
        //翻转
        [cell PosterFlip];
    }else
    {
        //居中显示
        [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition: UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        self.currentIndex = indexPath.item;
    }
}
//已经消失的单元格
-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    //强转并进行翻转
    PosterCell *posterCell = (PosterCell *)cell;
    if(posterCell.isTurn == 1)
    {
        [posterCell PosterFlip];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

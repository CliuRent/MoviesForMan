//
//  PosterCell.h
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MovieModel;
@class MovieDetailView;

@interface PosterCell : UICollectionViewCell

//imaageView
@property(nonatomic,strong)UIImageView *posterImageView;

//model
@property(nonatomic,strong)MovieModel *movie;

//翻转视图
@property(nonatomic,strong)MovieDetailView *detailView;

//是否翻转
@property(nonatomic,assign)BOOL isTurn;

//翻转方法
-(void)PosterFlip;

@end

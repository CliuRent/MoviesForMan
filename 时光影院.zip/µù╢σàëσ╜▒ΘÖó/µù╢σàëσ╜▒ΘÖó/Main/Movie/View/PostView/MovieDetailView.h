//
//  MovieDetailView.h
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class StarView;
@class MovieModel;

@interface MovieDetailView : UIView
{
    __weak IBOutlet UIImageView *_imgView;
    
    __weak IBOutlet UILabel *_titleLabel;
    
    __weak IBOutlet UILabel *_originalLabel;
    __weak IBOutlet UILabel *yearLabel;
    __weak IBOutlet StarView *_starView;
    __weak IBOutlet UILabel *ratingLabel;
}
@property(nonatomic,copy)MovieModel *movie;

@end

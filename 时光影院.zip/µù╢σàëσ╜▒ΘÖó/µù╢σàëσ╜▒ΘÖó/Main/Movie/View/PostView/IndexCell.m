//
//  IndexCell.m
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "IndexCell.h"
#import "MovieModel.h"

@implementation IndexCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //创建图片视图
        [self _createImgView];
    }
    return self;
}

-(void)_createImgView
{
    _imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.bounds.size.width * 0.95, self.bounds.size.height * 0.95)];
    _imgView.center = self.contentView.center;
    
    [self.contentView addSubview:_imgView];
}
-(void)setMovie:(MovieModel *)movie
{
    if(_movie != movie)
    {
        _movie = movie;
    }
    NSString *imgName = [movie.images objectForKey:@"medium"];
    
    //加载网络图片
    [_imgView sd_setImageWithURL:[NSURL URLWithString:imgName] placeholderImage:[UIImage imageNamed:@"pig"]];
}

@end

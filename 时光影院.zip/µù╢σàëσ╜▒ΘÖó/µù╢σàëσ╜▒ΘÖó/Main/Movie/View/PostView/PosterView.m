//
//  PosterView.m
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PosterView.h"
#import "PosterCollectionView.h"
#import "IndexCollectionView.h"
#import "MovieModel.h"

#define KheaderHeight 100
#define KfooterHeight 35

@implementation PosterView

//复写init方法
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //创建头视图
        [self _createHeaderView];
        
        //创建collectionView
        [self _createCollectionView];
        
        //创建灯视图
        [self _createLightView];
        
        //创建索引海报视图
        [self _createIndexColltion];
        
        //创建尾部视图
        [self _createFootView];
        //添加手势
        [self addGestureForSelf];
        
        
        //添加观察者模式
        [_posterCollection addObserver:self forKeyPath:@"currentIndex" options:NSKeyValueObservingOptionNew context:nil];
        [_indexColltion addObserver:self forKeyPath:@"currentIndex" options:NSKeyValueObservingOptionNew context:nil];
    }
    return self;
}

//观察者方法
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if([keyPath isEqualToString:@"currentIndex"])
    {
        //取出改变的的属性值
        NSInteger item = [[change objectForKey:@"new"]integerValue];
        
        //object 被观察者 
        if(object == _posterCollection && _indexColltion.currentIndex != item)
        {
            _indexColltion.currentIndex = item;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:item inSection:0];
            [_indexColltion scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        }else if (object == _indexColltion && _posterCollection.currentIndex != item)
        {
            _posterCollection.currentIndex = item;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:item inSection:0];
            [_posterCollection scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        }
        MovieModel *movie = _data[item];
        _footerLabel.text = movie.title;
    }
}

#pragma mark - 创建视图

-(void)_createLightView
{
    UIImage *lightImage = [UIImage imageNamed:@"light"];
    
    //拉伸图片
    lightImage = [lightImage stretchableImageWithLeftCapWidth:lightImage.size.width * 0.5f topCapHeight:lightImage.size.height * 0.5f];
    
    //左灯
    UIImageView *leftImageView = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth - 10)/2 - 90, 10, 60, 120)];
    leftImageView.image = lightImage;
    [self insertSubview:leftImageView aboveSubview:_posterCollection];
    
    //右灯
    UIImageView *rightImageView = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth - 10)/2 + 50, 10, 60, 120)];
    rightImageView.image = lightImage;
    [self insertSubview:rightImageView aboveSubview:_posterCollection];
}

-(void)_createFootView
{
    _footerLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, KScreenHeight - KfooterHeight - 49 - 64, KScreenWidth, KfooterHeight)];
    _footerLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"poster_title_home"]];
    _footerLabel.textAlignment = NSTextAlignmentCenter;
    _footerLabel.textColor = [UIColor colorWithRed:0 green:0.4 blue:0.5 alpha:1];
    _footerLabel.font = [UIFont systemFontOfSize:15];
    
    [self addSubview:_footerLabel];
}

-(void)_createIndexColltion
{
    _indexColltion = [[IndexCollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KheaderHeight)];
    //数据传递
    _indexColltion.cellWidth = 75;
    
    [_headerView addSubview:_indexColltion];
}

//创建头视图
-(void)_createHeaderView
{
    _headerView = [[UIView alloc]initWithFrame:CGRectMake(0,  - KheaderHeight, KScreenWidth, 130)];
    _headerView.backgroundColor = [UIColor clearColor];
    [self addSubview:_headerView];
    
    //创建背景图片
    UIImage *imag = [UIImage imageNamed:@"indexBG_home"];
    //拉伸图片
    imag = [imag stretchableImageWithLeftCapWidth:0 topCapHeight:1];
    
    UIImageView *bgimageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, 130)];
    bgimageView.image = imag;
    bgimageView.userInteractionEnabled = YES;
    [_headerView addSubview:bgimageView];
    
    //创建点击按钮
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake((KScreenWidth - 10)/2,130 - 20, 15, 15);
    [button setImage:[UIImage imageNamed:@"down_home"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"up_home"] forState:UIControlStateSelected];
    button.tag = 123;
    [_headerView addSubview:button];
    
    //添加点击事件
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
}

//创建collectionView
-(void)_createCollectionView
{
    _posterCollection = [[PosterCollectionView alloc]initWithFrame:CGRectMake(0,30, KScreenWidth, KScreenHeight - 64 - KfooterHeight- 30 - 49)];
    //数据传递
    _posterCollection.cellWidth = 220;
    _posterCollection.backgroundColor = [UIColor clearColor];
    
    [self insertSubview:_posterCollection belowSubview:_headerView];
}

//确保数据已经存在
-(void)setData:(NSMutableArray *)data
{
    if(_data != data)
    {
        _data = data;
        
        //传递数据
        _posterCollection.data = data;
        _indexColltion.data = data;
        
        if(data.count > 0)
        {
            MovieModel *movie = [data objectAtIndex:0];
            _footerLabel.text = movie.title;
        }
    }
}

//按钮点击事件
-(void)buttonAction:(UIButton *)button
{
    button.selected = !button.selected;
    if(button.selected == YES)    //显示
    {
        [self showView];
    }else
    {
        [self hideView];
    }
}

//按钮选中状态为yes ,显示
-(void)showView
{
    //动画    
    [UIView animateWithDuration:.2 animations:^{
        _headerView.transform = CGAffineTransformMakeTranslation(0, KheaderHeight);
    }];
    
    //创建遮盖视图
    if(_maskView == nil)
    {
        _maskView = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight)];
        _maskView.backgroundColor = [UIColor colorWithWhite:0.2 alpha:.5];
        [self insertSubview:_maskView belowSubview:_headerView];
    }
    _maskView.hidden = NO;
    
    //取到Button
    UIButton *button = (UIButton *)[_headerView viewWithTag:123];
    button.selected = YES;
}
//收缩
-(void)hideView
{
    _headerView.transform = CGAffineTransformIdentity;
    _maskView.hidden = YES;
    
    UIButton *button = (UIButton *)[_headerView viewWithTag:123];
    button.selected = NO;
}
//添加手势
-(void)addGestureForSelf
{
    UISwipeGestureRecognizer *swip = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(showView)];
    //设置下拉手势方向
    swip.direction = UISwipeGestureRecognizerDirectionDown;
    
    [self addGestureRecognizer:swip];
    
    //添加上推手势
    UISwipeGestureRecognizer *upSwipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(hideView)];
    //设置方向
    upSwipe.direction = UISwipeGestureRecognizerDirectionUp;
    [self addGestureRecognizer:upSwipe];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

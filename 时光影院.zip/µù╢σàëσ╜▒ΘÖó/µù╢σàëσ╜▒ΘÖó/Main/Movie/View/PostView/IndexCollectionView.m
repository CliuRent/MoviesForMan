//
//  IndexCollectionView.m
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "IndexCollectionView.h"
#import "IndexCell.h"

@implementation IndexCollectionView

-(instancetype)initWithFrame:(CGRect)frame
{
    //创建布局对象
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    
    //设置间隙
    flowLayout.minimumLineSpacing = 0;
    //设置滑动方向
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    self = [super initWithFrame:frame collectionViewLayout:flowLayout];
    if(self)
    {
        //设置代理
        self.delegate = self;
        self.dataSource = self;
        
        //设置滑动的减速度
        self.decelerationRate = UIScrollViewDecelerationRateFast;
        
        //滚动条的显示
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        
        //注册单元格
        [self registerClass:[IndexCell class] forCellWithReuseIdentifier:@"indexCell"];
    }
    return self;
}

#pragma mark - 数据源以及代理方法

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _data.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //单元格的服用
    IndexCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"indexCell" forIndexPath:indexPath];
    
    //数据传递
    cell.movie = _data[indexPath.item];
    return cell;
}
//单元格大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(_cellWidth,CGRectGetHeight(self.frame));
}
//单元格的偏移
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    CGFloat offSetX = (CGRectGetWidth(self.frame) - _cellWidth)/2;
    return UIEdgeInsetsMake(0, offSetX, 0, offSetX);
}

-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    int index = (targetContentOffset->x + _cellWidth/2)/_cellWidth;
    
    targetContentOffset->x = index * _cellWidth;
    
    //记录当前索引
    self.currentIndex = index;
}
//单元格点击方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.currentIndex != indexPath.item)
    {
        //居中显示
        [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        
        //记录当前索引
        self.currentIndex = indexPath.item;
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

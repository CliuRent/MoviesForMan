//
//  PosterCollectionView.h
//  时光影院
//
//  Created by admin on 16/8/31.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PosterCollectionView : UICollectionView<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

//数据
@property(nonatomic,strong)NSMutableArray *data;

//当前索引下标
@property(nonatomic,assign)NSInteger currentIndex;

//单元格宽
@property(nonatomic,assign)CGFloat cellWidth;

@end

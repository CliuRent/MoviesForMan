//
//  IndexCollectionView.h
//  时光影院
//
//  Created by admin on 16/9/8.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexCollectionView : UICollectionView<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate>

//数据
@property(nonatomic,strong)NSMutableArray *data;

//单元格宽度
@property(nonatomic,assign)CGFloat cellWidth;
//单元格索引
@property(nonatomic,assign)NSInteger currentIndex;


@end

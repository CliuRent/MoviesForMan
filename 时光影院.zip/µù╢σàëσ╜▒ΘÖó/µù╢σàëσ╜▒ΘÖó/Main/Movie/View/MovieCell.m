//
//  MovieCell.m
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "MovieCell.h"
#import "MovieModel.h"
#import "UIImageView+WebCache.h"
#import "StarView.h"

@implementation MovieCell

//有XIB文件会优先调用此方法
- (void)awakeFromNib {
    // Initialization code
    //背景颜色
    self.selectionStyle = 0;
    self.backgroundColor = [UIColor clearColor];
    //辅助图标 箭头
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

//setter方法
-(void)setMovieModel:(MovieModel *)movieModel
{
    _movieModel = movieModel;
    
    //填充数据
    titleLable.text = movieModel.title;
    yearLable.text = [NSString stringWithFormat:@"年份:%@",movieModel.year];
    averageLable.text = [NSString stringWithFormat:@"%.1f",[movieModel.average floatValue]];
    averageLable.textColor = [UIColor orangeColor]
    ;
    //图片
    NSString *imageName = [movieModel.images objectForKey:@"small"];
    
    //加载网络图片
    NSURL *url = [NSURL URLWithString:imageName];
    [movieImageview sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"pig"]];
    
    //评分
    starView.rating = [movieModel.average floatValue];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  MovieModel.h
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieModel : NSObject

/*
 解析json文件后我们需要的属性
 需要注意的是基本数据类型在json中被包装成NSNumber类型
 */

//评分
@property(nonatomic,strong)NSNumber *average;

//标题
@property(nonatomic,copy)NSString *title;

//原标题
@property(nonatomic,copy)NSString *original_title;

//种类
@property(nonatomic,copy)NSString *subtype;

//年份
@property(nonatomic,copy)NSString *year;

//电影图片
@property(nonatomic,copy)NSDictionary *images;

//电影ID
@property(nonatomic,copy)NSString *movieId;

//收藏人数
@property(nonatomic,strong)NSNumber *collect_count;

@end

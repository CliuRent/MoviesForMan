//
//  MovieModel.m
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "MovieModel.h"

@implementation MovieModel

@end

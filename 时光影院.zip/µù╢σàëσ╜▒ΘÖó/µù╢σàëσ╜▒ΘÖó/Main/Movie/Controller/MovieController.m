//
//  MovieController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "MovieController.h"
#import "MovieModel.h"
#import "MovieCell.h"
#import "PosterView.h"

@interface MovieController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation MovieController

- (void)viewDidLoad {
    [super viewDidLoad];
    //数据的初始化放在最前
    
    //创建导航项右按钮
    [self _loadNavigationItem];
    
    //创建翻转视图
    [self _loadView];
    
    [self _loadData];
//    self.navigationController.navigationBar.translucent = YES;
    
//    //适配
//    self.automaticallyAdjustsScrollViewInsets = YES;
//    //设置ScrollerView对象的延伸方向
//    self.edgesForExtendedLayout = UIRectEdgeTop | UIRectEdgeBottom;
    
}

#pragma mark - 数据的初始化以及读取
-(void)_loadData
{
    //数组初始化
    _data = [NSMutableArray array];
    
    //读取文件
    
    //获取文件路径
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"us_box" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    
    //json文件解析
    NSMutableDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray *array = [jsonDic objectForKey:@"subjects"];
    //遍历数组
    for (NSDictionary *dic  in array) {
        NSDictionary *movieDic = [dic objectForKey:@"subject"];
        
        //创建movieModel
        MovieModel *movieModel = [[MovieModel alloc]init];
        //填充数据
        movieModel.average = [[movieDic objectForKey:@"rating"]objectForKey:@"average"];
        
        movieModel.title = [movieDic objectForKey:@"title"];
        
        movieModel.original_title = [movieDic objectForKey:@"original_title"];
        
        movieModel.subtype = [movieDic objectForKey:@"subtype"];
        
        movieModel.year = [movieDic objectForKey:@"year"];
        
        movieModel.movieId = [movieDic objectForKey:@"id"];
        
        movieModel.collect_count = [movieDic objectForKey:@"collect_count"];
        
        //images
        movieModel.images = [movieDic objectForKey:@"images"];
        
        //添加到数组中
        [_data addObject:movieModel];
        
    }
    //加载完数据刷新表视图
    [_tableView reloadData];
    
    _posterView.data = _data;
}

#pragma mark - 视图的初始化
-(void)_loadView
{
    //_tableView先添加到self.view上，让海报视图覆盖表视图
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - 49 - 64) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main@2x"]];
    _tableView.hidden = YES;
    
    _tableView.rowHeight = 120;
    _tableView.separatorColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"tableView_line_home@2x"]];
    
    //设置数据源及代理对象
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    //添加
    [self.view addSubview:_tableView];
    
    //创建海报视图
    _posterView  = [[PosterView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - 64 - 49)];
    _posterView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    _posterView.hidden = NO;
    
//    _posterView.data = _data;
    
    //添加到父视图
    [self.view addSubview:_posterView];
}

#pragma mark - loadNavigationItem
-(void)_loadNavigationItem
{
    //创建父视图
    UIView *buttonView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 50, 34)];
    
    //创建POST按钮
    UIButton *PostBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    PostBtn.frame = buttonView.frame;
    [PostBtn setImage:[UIImage imageNamed:@"poster_home"] forState:UIControlStateNormal];
    [PostBtn setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home@2x"] forState:UIControlStateNormal];
    PostBtn.tag = 200;
    
    //添加点击事件
    [PostBtn addTarget:self action:@selector(rightBarItemAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [buttonView addSubview:PostBtn];
    
    //创建LIST按钮
    UIButton *ListBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    ListBtn.frame = buttonView.frame;
    [ListBtn setImage:[UIImage imageNamed:@"list_home"] forState:UIControlStateNormal];
    [ListBtn setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home@2x"] forState:UIControlStateNormal];
    ListBtn.tag = 201;
    
    //添加点击事件
    [ListBtn addTarget:self action:@selector(rightBarItemAction:) forControlEvents:UIControlEventTouchUpInside];
    ListBtn.hidden = YES;
    
    [buttonView addSubview:ListBtn];
    
    //包装父视图
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:buttonView];
    self.navigationItem.rightBarButtonItem = rightItem;
}
//按钮点击事件实现
-(void)rightBarItemAction:(UIButton *)button
{
    //取到父视图
    UIView *buttonView = self.navigationItem.rightBarButtonItem.customView;
    
    //通过Tag取到按钮
    UIButton *PostBtn = (UIButton *)[buttonView viewWithTag:200];
    UIButton *ListBrn = (UIButton *)[buttonView viewWithTag:201];
    
    //hidden属性
    PostBtn.hidden = !PostBtn.hidden;
    ListBrn.hidden = !ListBrn.hidden;
    
    //调用翻转方法
    [self flipView:buttonView isTransiton:PostBtn.hidden];
    
    //同上.翻转视图
    _posterView.hidden = !_posterView.hidden;
    _tableView.hidden = !_tableView.hidden;
    
    //调用翻转方法
    [self flipView:self.view isTransiton:PostBtn.hidden];
    
    }

-(void)flipView:(UIView *)forView isTransiton:(BOOL)flag
{
    //翻转动画
    UIViewAnimationOptions options = flag ? UIViewAnimationOptionTransitionFlipFromRight : UIViewAnimationOptionTransitionFlipFromLeft;
    
    [UIView transitionWithView:forView duration:.3 options:options animations:^{
        //父视图交换子视图的下标
        [forView exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
    } completion:nil];

}
#pragma mark - 数据源及代理方法
//返回每组单元格数目
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _data.count;
}
//创建cell
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MovieCell *cell = [tableView dequeueReusableCellWithIdentifier:@"moviwCell"];
    if(!cell)
    {
        //读取xib文件
        cell = [[[NSBundle mainBundle]loadNibNamed:@"MovieCell" owner:self options:nil]lastObject];
    }
    cell.movieModel = _data[indexPath.row];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

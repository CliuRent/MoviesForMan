//
//  MovieController.h
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "BaseViewController.h"
@class PosterView;

@interface MovieController : BaseViewController
{
    PosterView *_posterView;
    UITableView *_tableView;
}
@property(nonatomic,strong)NSMutableArray *data;

@end

//
//  CinemaModel.m
//  时光影院
//
//  Created by admin on 16/8/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "CinemaModel.h"

@implementation CinemaModel

@end

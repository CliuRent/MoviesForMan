//
//  DistrictModel.m
//  时光影院
//
//  Created by admin on 16/8/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "DistrictModel.h"

@implementation DistrictModel

@end

//
//  CinemaModel.h
//  时光影院
//
//  Created by admin on 16/8/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CinemaModel : NSObject

//最低价格
@property(nonatomic,copy)NSString *lowPrice;

//评分
@property(nonatomic,copy)NSString *grade;

//详细地址
@property(nonatomic,copy)NSString *address;
//影院名
@property(nonatomic,copy)NSString *name;

//电话
@property(nonatomic,copy)NSString *tel;

//地址
@property(nonatomic,copy)NSString *circleName;

//ID
@property(nonatomic,copy)NSString *districtId;


@end

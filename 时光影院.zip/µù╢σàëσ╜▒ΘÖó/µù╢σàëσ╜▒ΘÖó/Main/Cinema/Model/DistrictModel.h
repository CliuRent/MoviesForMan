//
//  DistrictModel.h
//  时光影院
//
//  Created by admin on 16/8/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DistrictModel : NSObject

//分区
@property(nonatomic,copy)NSString *name;

//ID
@property(nonatomic,copy)NSString *nameId;


@end

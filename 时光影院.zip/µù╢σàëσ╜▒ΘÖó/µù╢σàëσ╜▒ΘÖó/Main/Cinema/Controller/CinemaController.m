//
//  CinemaController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "CinemaController.h"
#import "CinemaModel.h"
#import "CinemaCell.h"
#import "DistrictModel.h"

@interface CinemaController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_data;
    NSMutableArray *_group;
    BOOL compare[20];
    NSMutableArray *_cellArray;
}
@end

@implementation CinemaController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //读取数据
    [self _loadData];
    [self _loadGroup];
    [self loadCellData];
    
    //初始化表视图
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - 113) style:UITableViewStylePlain];
    
    //表视图背景
    _tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main@2x"]];
    
    //设置数据源及代理对象
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    //单元格高度
    _tableView.rowHeight = 80;
    
    //添加
    [self.view addSubview:_tableView];
    // Do any additional setup after loading the view.
}

#pragma mark  - 读取数据
-(void)_loadData
{
    //初始化数组
    _data = [NSMutableArray array];
    
    //将读取json文件的方法包装成一个小框架，使整个工程目录下都能使用
    NSDictionary *dic = (NSDictionary *)[RequestData requsetDataWithFileName:@"cinema_list.json"];
    NSArray *array = [dic objectForKey:@"cinemaList"];
    
    //遍历数组
    for (NSDictionary *dic in array) {
        //创建model对象
        CinemaModel *cinema = [[CinemaModel alloc]init];
        cinema.lowPrice = dic[@"lowPrice"];
        cinema.grade = dic[@"grade"];
        cinema.name = dic[@"name"];
        cinema.address = dic[@"address"];
        cinema.tel = dic[@"tel"];
        cinema.circleName = dic[@"circleName"];
        cinema.districtId = dic[@"districtId"];
        
        //将model对象添加到数组中
        [_data addObject:cinema];
    }
}
//初始化组
-(void)_loadGroup
{
    //初始化数组
    _group = [NSMutableArray array];
    
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"district_list" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    
    //解析json文件
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    NSArray *array = [dic objectForKey:@"districtList"];
    
    //遍历
    for (NSDictionary *dic in array) {
        //创建model
        DistrictModel *district = [[DistrictModel alloc]init];
        district.name = dic[@"name"];
        district.nameId = dic[@"id"];
        
        [_group addObject:district];
    }
}

//得到每一个组的不同数据
-(void)loadCellData
{
    //初始化数组
    _cellArray = [NSMutableArray array];
    //遍历数组
    for(int i = 0;i < _group.count;i++)
    {
        //取出districtModel
        DistrictModel *district = _group[i];
        NSMutableArray *array = [NSMutableArray array];
        
        for (int j = 0; j < _data.count;j++) {
            //取出每一个cinemaModel
            CinemaModel *cinema = _data[j];
            
            //比较
            if([district.nameId isEqualToString:cinema.districtId])
            {
                [array addObject:cinema];
            }
        }
        //添加
        [_cellArray addObject:array];
    }
    //刷新表视图
    [_tableView reloadData];
}

#pragma mark - 数据源及代理方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = _cellArray[section];
    if(!compare[section])
    {
        return 0;
    }else
    {
        return array.count;
    }
}

//创建cell
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //从复用池中获取
    CinemaCell *cinemaCell = [tableView dequeueReusableCellWithIdentifier:@"cinemaCell"];
    if(!cinemaCell)
    {
        //读取xib文件
        cinemaCell = [[[NSBundle mainBundle]loadNibNamed:@"CinemaCell" owner:self options:nil]lastObject];
    }
    NSArray *array = _cellArray[indexPath.section];
    cinemaCell.cinema = array[indexPath.row];
    return cinemaCell;
}
//组数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _group.count;
}

//设置组头视图
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    //背景颜色
    [button setBackgroundImage:[UIImage imageNamed:@"hotMovieBottomImage@2x"] forState:UIControlStateNormal];
    //设置标题
    DistrictModel *district = _group[section];
    [button setTitle:district.name forState:UIControlStateNormal];
    
    //设置tag
    button.tag = 100 + section;
    
    //添加点击事件
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    //创建imageView
    UIImageView *leftImage = [[UIImageView alloc]initWithFrame:CGRectMake(10, 22, 22, 13)];
    leftImage.image = [UIImage imageNamed:@"whiteTriangle@2x"];
    [button addSubview:leftImage];
    leftImage.hidden = YES;
    leftImage.tag = 1234;
    
    return button;
}

//点击事件实现
-(void)buttonAction:(UIButton *)button
{
    button.selected = !button.selected;
    
    UIImageView *leftImage = (UIImageView *)[button viewWithTag:1234];
    
    //取得button的tag
    NSInteger section = button.tag - 100;
    if(button.selected == YES)
    {
        //取反
        compare[section] = !compare[section];
        
        //刷新组
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:section];
        [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationFade];
        leftImage.hidden = NO;
    }
}

//设置组头视图高
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  CinemaCell.m
//  时光影院
//
//  Created by admin on 16/8/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "CinemaCell.h"
#import "CinemaModel.h"

@implementation CinemaCell

- (void)awakeFromNib {
    // Initialization code
    
    //单元格背景颜色
    self.backgroundColor = [UIColor clearColor];
    
    //辅助图标
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    //单元格选中状态
    self.selectionStyle = 0;
}
//确保此时cinemaModel存在
-(void)setCinema:(CinemaModel *)cinema
{
    _cinema = cinema;
    
    //填充数据
    nameLable.text = cinema.name;
    nameLable.textColor = [UIColor whiteColor];
    
    gradeLable.text = cinema.grade;
    gradeLable.textColor = [UIColor orangeColor];
    
    adressLable.text = cinema.address;
    adressLable.textColor = [UIColor grayColor];
    adressLable.font = [UIFont systemFontOfSize:13];
    
    if([cinema.lowPrice isKindOfClass:[NSNull class]])
    {
        priceLable.textColor = [UIColor orangeColor];
        priceLable.text = @"你猜猜";
    }else
    {
        priceLable.textColor = [UIColor orangeColor];
        priceLable.text = [NSString stringWithFormat:@"¥ %@",cinema.lowPrice];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  MoreController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "MoreController.h"

@interface MoreController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
{
    NSArray *_images;
    NSArray *_showInfos;
    UITableView *_tableView;
    
    //缓存label
    UILabel *_cacheLabel;
}
@end

@implementation MoreController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _loadData];    //加载数据
    
    self.view.backgroundColor = [UIColor blackColor];
    
    //创建tableView
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, 44 * 7) style:UITableViewStyleGrouped];
    
    _tableView.backgroundColor = [UIColor blackColor];
    
    _tableView.scrollEnabled = NO;
    
    _cacheLabel = [[UILabel alloc]initWithFrame:CGRectMake(KScreenWidth - 50, 12, 50, 22)];
    _cacheLabel.tag = 145;
    _cacheLabel.text = @"缓存";
    _cacheLabel.textColor = [UIColor whiteColor];
    
    //设置代理对象
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self countCacheSize];
}

-(void)countCacheSize
{
    NSUInteger cacheSize = [[SDImageCache sharedImageCache]getSize];
    
    _cacheLabel.text = [NSString stringWithFormat:@"%.1fM",cacheSize / 1024 / 1024.0];
}

//初始化数据
-(void)_loadData
{
    _images = @[@"moreClear@2x",@"moreScore@2x",@"moreVersion@2x",@"moreBusiness@2x",@"moreWelcome@2x",@"moreAbout@2x"];
    _showInfos = @[@"清除缓存",@"给个评价",@"检查新版本",@"商务合作",@"欢迎页",@"关于"];
}

#pragma mark - 数据源及代理方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _images.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //复用
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableCell"];
    if(!cell)
    {
        //若没有，则手动创建
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"tableCell"];
        if(indexPath.row == 0)
        {
            [cell.contentView addSubview:_cacheLabel];
        }
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = 0;
    }
    
    //填充数据
    cell.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",_images[indexPath.row]]];
    cell.imageView.contentMode = 1;
    cell.textLabel.text = _showInfos[indexPath.row];
    cell.textLabel.textColor = [UIColor whiteColor];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 22;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 22;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"清理缓存" message:@"主人，真的狠心清除奴婢吗，喵~~" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        [alertView show];
    }
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        //清理缓存
        [[SDImageCache sharedImageCache]clearDisk];
        
        //重新计算缓存
        [self countCacheSize];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

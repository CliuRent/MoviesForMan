//
//  NewsController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "NewsController.h"
#import "NewsModel.h"
#import "NewsCellTableViewCell.h"

@interface NewsController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_data;
    
    //标题label
    UILabel *_titleLable;
    //图片
    UIImageView *_imageView;
    //头视图
    UIImageView *_hearImageView;
}
@end

@implementation NewsController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _loadData];
    
    //当自动适配失败时，我们需要手动设置适配：
    self.automaticallyAdjustsScrollViewInsets = YES;
    self.edgesForExtendedLayout = UIRectEdgeTop | UIRectEdgeBottom; //垂直方向上适配
    
    //初始化表视图
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - 49 - 64) style:UITableViewStylePlain];
    //设置数据源以及代理对象
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    //创建头视图图片视图
    _hearImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, 150)];
    _tableView.tableHeaderView = _hearImageView;
    
    //单元格高度
    _tableView.rowHeight = 80;
    //单元格分割样式
    _tableView.separatorStyle = NO;
    
    //注册单元格
//    [_tableView registerClass:[NewsCellTableViewCell class] forCellReuseIdentifier:@"newsCell"];
    
    [self.view addSubview:_tableView];
    [self _createImageView];

    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    self.navigationController.navigationBar.translucent = NO;
}

-(void)_createImageView
{
    //创建一个imageView漂浮在组头视图的位置
    _imageView = [[UIImageView alloc]initWithFrame:_hearImageView.bounds];
    _imageView.image = [UIImage imageNamed:@"header.jpg"];
    
    //创建Lable
    _titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, _imageView.frame.size.height - 30, _imageView.frame.size.width, 30)];
    NewsModel *newsModel = _data[0];
    _titleLable.text = newsModel.title;
    _titleLable.font = [UIFont systemFontOfSize:18];
    _titleLable.textColor = [UIColor whiteColor];
    
    //插入到表视图之上
    [self.view insertSubview:_titleLable aboveSubview:_imageView];
    [self.view insertSubview:_imageView aboveSubview:_tableView];
}

//初始化数据
-(void)_loadData
{
    //数组初始化
    _data = [NSMutableArray array];
    
    //读取文件
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"news_list" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    
    //解析json文件
    NSArray *array = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    //遍历数组
    for(int i = 0;i < array.count;i++) {
        
        NSDictionary *dic = array[i];
        //创建newsModel对象
        NewsModel *news = [[NewsModel alloc]init];
        news.image = [dic objectForKey:@"image"];
        news.title = [dic objectForKey:@"title"];
        news.summary = [dic objectForKey:@"summary"];
        news.type = [dic objectForKey:@"type"];
        
        //将news对象添加到数组中
        [_data addObject:news];
    }
    //初始化数据后刷新一次表视图
    [_tableView reloadData];
}

#pragma mark - 数据源及代理方法
//每组单元格数目
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _data.count - 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //从复用池中获取cell
    NewsCellTableViewCell *newsCell = [tableView dequeueReusableCellWithIdentifier:@"newsCell"];
    if(!newsCell)
    {
        //从xib文件中获取
        newsCell = [[[NSBundle mainBundle]loadNibNamed:@"NewsCellTableViewCell" owner:self options:nil]lastObject];
    }
    //传递数据
    newsCell.news = _data[indexPath.row + 1];
    
    return newsCell;
}

//实时调用
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //只需Y轴的偏移量  向上为正，向下为负
    CGFloat offSetY = scrollView.contentOffset.y;
    
    if(offSetY > 0)
    {
        //获取到_imageView的坐标
        CGRect frameImageView = _imageView.frame;
        frameImageView.origin.y = -offSetY;
        _imageView.frame = frameImageView;
    }else
    {
        //获取放大后图片的高度  ABS取绝对值
        CGFloat height = _hearImageView.frame.size.height + ABS(offSetY);
        
        // 原宽/原高 = 放大后的宽/放大后的高  放大后比例不变
        CGFloat width = KScreenWidth / _hearImageView.frame.size.height * height;
        
        //放大后的坐标
        _imageView.frame = CGRectMake(-(width - KScreenWidth)/2, 0, width, height);
    }
    
    //设置titleLabel的坐标
    CGRect frame = _titleLable.frame;
    frame.origin.y = CGRectGetMaxY(_imageView.frame) - _titleLable.frame.size.height;
    _titleLable.frame = frame;
    
}
//点击跳转到相应页面
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NewsModel *news = _data[indexPath.row + 1];
    
    NSInteger type = [news.type integerValue];
    
    if(type == 0)
    {
        //从故事版中获取到控制器
        UIViewController *newsDetailController = [self.storyboard instantiateViewControllerWithIdentifier:@"newsDetail"];
        newsDetailController.hidesBottomBarWhenPushed = YES;
        //跳转
        [self.navigationController pushViewController:newsDetailController animated:YES];
    }else if (type == 1)
    {
        //从故事版中取到控制器
        UIViewController *imageListController = [self.storyboard instantiateViewControllerWithIdentifier:@"imageList"];
        //push后隐藏
        imageListController.hidesBottomBarWhenPushed = YES;
        //实现跳转
        [self.navigationController pushViewController:imageListController animated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

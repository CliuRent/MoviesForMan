//
//  NewsDetailController.m
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "NewsDetailController.h"

@interface NewsDetailController ()<UIWebViewDelegate>

@end

@implementation NewsDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    
    _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - 64)];
    
//    //加载网络url
//    NSURL *urlString = [NSURL URLWithString:@"http://www.baidu.com"];
//    NSURLRequest *urlResquest = [[NSURLRequest alloc]initWithURL:urlString];
//    [_webView loadRequest:urlResquest];
//    
    [self.view addSubview:_webView];
    
    [self _loadData];
    
    // Do any additional setup after loading the view.
}

//读取数据
-(void)_loadData
{
    NSDictionary *jsonDic = (NSDictionary *)[RequestData requsetDataWithFileName:@"news_detail.json"];
    
    NSString *title = [jsonDic objectForKey:@"title"];
    NSString *content = [jsonDic objectForKey:@"content"];
    NSString *time = [jsonDic objectForKey:@"time"];
    NSString *source = [jsonDic objectForKey:@"source"];
    NSString *author = [jsonDic objectForKey:@"author"];
    
    //读取html文件
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"news" ofType:@"html"];
    NSString *html = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    //拼接
    NSString *subTitle = [NSString stringWithFormat:@"%@ %@",source,time];
    
    NSString *auth = [NSString stringWithFormat:@"来自无比睿智的%@",author];
    
    //拼接html
    NSString *htmlString = [NSString stringWithFormat:html,title,subTitle,content,auth];
    
    [_webView loadHTMLString:htmlString baseURL:nil];
    
    //自适应
    _webView.scalesPageToFit = YES;
    
    _webView.delegate = self;
    
    //小菊花
    _activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    UIBarButtonItem *rightBarBtn = [[UIBarButtonItem alloc]initWithCustomView:_activityView];
    self.navigationItem.rightBarButtonItem = rightBarBtn;
}

-(void)webViewDidStartLoad:(UIWebView *)webView
{
    [_activityView startAnimating];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_activityView stopAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  ImageListController.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageListController : UIViewController
{
    
    __weak IBOutlet UICollectionView *_collectionView;
}

@property(nonatomic,copy)NSMutableArray *data;
@end

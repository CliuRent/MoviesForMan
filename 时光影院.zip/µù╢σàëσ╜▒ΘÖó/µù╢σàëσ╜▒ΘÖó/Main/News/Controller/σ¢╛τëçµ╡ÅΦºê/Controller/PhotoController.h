//
//  PhotoController.h
//  时光影院
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PhotoCollectionView;
@interface PhotoController : UIViewController
{
    BOOL _isHidden;
}
//可变数组接收图片url
@property(nonatomic,strong)NSMutableArray *imageUrls;

//索引
@property(nonatomic,strong)NSIndexPath *indexPath;

@property(nonatomic,strong)PhotoCollectionView *photoCollection;
@end

//
//  PhotoController.m
//  时光影院
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PhotoController.h"
#import "PhotoCollectionView.h"

@interface PhotoController ()
{
    UICollectionView *_colleection;
}

@end

@implementation PhotoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _isHidden = NO;
    
    //创建leftBarButton
//    UIBarButtonItem *letfBtn = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:0 target:self action:@selector(letfBtnAction)];
//    self.navigationItem.leftBarButtonItem = letfBtn;
    
    //创建集合视图
    _photoCollection = [[PhotoCollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight)];
    
    _photoCollection.imageUrls = _imageUrls;
    
    //设置背景颜色
    _photoCollection.backgroundColor = [UIColor grayColor];
    
    //改变导航栏的样式
    UINavigationBar *navigationBar = self.navigationController.navigationBar;
    [navigationBar setBackgroundImage:nil forBarMetrics:0];
    navigationBar.barStyle = UIBarStyleBlack;
    navigationBar.translucent = YES;
    
    //跳转
    [_photoCollection scrollToItemAtIndexPath:_indexPath atScrollPosition:0 animated:YES];
    
    [self.view addSubview:_photoCollection];
    
    //监听通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receiveNoti:) name:@"single" object:nil];
    
    // Do any additional setup after loading the view.
}

//接收通知实现方法
-(void)receiveNoti:(NSNotification *)noti
{
    _isHidden = !_isHidden;
    [self.navigationController setNavigationBarHidden:_isHidden animated:YES];
}

//隐藏状态栏
-(BOOL)prefersStatusBarHidden
{
    return _isHidden;
}

//按钮点击方法实现
-(void)letfBtnAction
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  PhotoCell.m
//  时光影院
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PhotoCell.h"
#import "PhotoScrollView.h"

@implementation PhotoCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self  = [super initWithFrame:frame];
    if(self)
    {
        _scrollerView = [[PhotoScrollView alloc]initWithFrame:self.bounds];
        [self.contentView addSubview:_scrollerView];
    }
    return self;
}

//确保图片名存在
-(void)setUrl:(NSString *)url
{
    if(_url != url)
    {
        _url = url;
        _scrollerView.url = [NSURL URLWithString:_url];
    }
}

@end

//
//  PhotoCollectionView.m
//  时光影院
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PhotoCollectionView.h"
#import "PhotoCell.h"
#import "PhotoScrollView.h"

@implementation PhotoCollectionView

-(instancetype)initWithFrame:(CGRect)frame
{
    //创建布局对象
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    
    //设置布局对象的属性
    
    //单元格大小
    layout.itemSize = CGSizeMake(KScreenWidth, KScreenHeight);
    
    //单元格之间的间隙
    layout.minimumLineSpacing = 0;
    
    //单元格滑动方向
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if(self)
    {
        self.dataSource = self;
        self.delegate = self;
        //分页显示
        self.pagingEnabled = YES;
        
        //注册单元格
        [self registerClass:[PhotoCell class] forCellWithReuseIdentifier:@"cell"];
        
    }
    return self;
}

#pragma mark - 数据源方法及代理方法
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _imageUrls.count;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(KScreenWidth, KScreenHeight - 64);
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    //传递数据
    cell.url = _imageUrls[indexPath.row];
    return cell;
}

//滑动时缩放还原
-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    //类型转化
    PhotoCell *PhotCell = (PhotoCell *)cell;
    [PhotCell.scrollerView setZoomScale:1.0 animated:YES];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

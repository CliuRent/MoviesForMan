//
//  PhotoScrollView.m
//  时光影院
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PhotoScrollView.h"

@implementation PhotoScrollView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _scrollImageView = [[UIImageView alloc]initWithFrame:self.bounds];
        
        [self addSubview:_scrollImageView];
        //设置填充方式，避免图片拉伸过度
        _scrollImageView.contentMode = 1;
        
        //缩放倍数
        self.minimumZoomScale = 0.5;
        self.maximumZoomScale = 4.0;
        
        //隐藏滚动条
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        
        //添加手势
        //单击
        UITapGestureRecognizer *single = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTap)];
        single.numberOfTapsRequired = 1;
        [self addGestureRecognizer:single];
        
        //双击
        UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTap)];
        doubleTap.numberOfTapsRequired = 2;
        [self addGestureRecognizer:doubleTap];
        
        //单击与双击的冲突解决
        [single requireGestureRecognizerToFail:doubleTap];
        
        //设置代理对象
        self.delegate = self;
    }
    return self;
}

//单击实现的方法
-(void)singleTap
{
    //发送通知
    [[NSNotificationCenter defaultCenter]postNotificationName:@"single" object:self userInfo:nil];
}

//双击实现的方法
-(void)doubleTap
{
    if(self.zoomScale <= 1.0)
    {
        [self setZoomScale:3.0 animated:YES];
    }else
    {
        [self setZoomScale:1.0 animated:YES];
    }
}

//指定图片
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _scrollImageView;
}

-(void)setUrl:(NSURL *)url
{
    if(_url != url)
    {
        _url = url;
        
        //加载网络图片
        [_scrollImageView sd_setImageWithURL:_url placeholderImage:[UIImage imageNamed:@"pig"]];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

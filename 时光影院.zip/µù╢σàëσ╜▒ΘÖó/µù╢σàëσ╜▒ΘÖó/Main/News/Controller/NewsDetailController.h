//
//  NewsDetailController.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsDetailController : UIViewController
{
    UIWebView *_webView;
    UIActivityIndicatorView *_activityView;
}
@end

//
//  ImageListController.m
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ImageListController.h"
#import "NewsModel.h"
#import "PhotoController.h"

@interface ImageListController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@end

@implementation ImageListController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _loadData];
    
    //集合视图的背景
    _collectionView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    self.navigationItem.title = @"图片集";
    
    //添加滑动手势
    UISwipeGestureRecognizer *swip = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipAction)];
    
    swip.direction = UISwipeGestureRecognizerDirectionRight;
    
    [_collectionView addGestureRecognizer:swip];
    
    //设置数据源及代理对象
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.translucent = NO;
}

-(void)swipAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)_loadData
{
    //解析json 文件
    NSArray *array = (NSArray *)[RequestData requsetDataWithFileName:image_list];
    
    //初始化数组
    _data = [NSMutableArray array];
    
    //遍历数组
    for (NSDictionary *dic in array) {
        //创建Model
        NewsModel *news = [[NewsModel alloc]init];
        news.image = dic[@"image"];
        
        [_data addObject:news];
    }
    //刷新集合视图
    [_collectionView reloadData];
}

#pragma mark - 数据源及代理方法
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _data.count;
}
//创建单元格
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"imageList" forIndexPath:indexPath];
    
    NewsModel *news = _data[indexPath.row];
    
    UIImageView *imgView = (UIImageView *)[cell.contentView viewWithTag:200];
    
    //加载网络图片
    [imgView sd_setImageWithURL:[NSURL URLWithString:news.image] placeholderImage:[UIImage imageNamed:@"pig"]];
    return cell;
}

//点击单元格跳转
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //创建视图控制器
    PhotoController *photo = [[PhotoController alloc]init];
    photo.imageUrls = [NSMutableArray array];
    //遍历数组
    for (NewsModel *news in _data) {
        [photo.imageUrls addObject:news.image];
    }
    
    photo.indexPath = indexPath;
    
    [self.navigationController pushViewController:photo animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

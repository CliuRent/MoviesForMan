//
//  NewsCellTableViewCell.m
//  时光影院
//
//  Created by admin on 16/8/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "NewsCellTableViewCell.h"
#import "NewsModel.h"
#import "UIImageView+WebCache.h"

@implementation NewsCellTableViewCell

- (void)awakeFromNib {
    // Initialization code
    //辅助图标  箭头
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    //背景透明色
    self.backgroundColor = [UIColor clearColor];
    
}

-(void)setNews:(NewsModel *)news
{
    _news = news;
    
    summaryLable.transform = CGAffineTransformIdentity;
    //type的几张图片
    UIImage *imagePlay = [UIImage imageNamed:@"scspxw"]; // 播放图标 type 2
    UIImage *image2 = [UIImage imageNamed:@"sctpxw"];    //         type 1
    
    //填充数据
    titleLable.text = news.title;
    titleLable.font = [UIFont systemFontOfSize:15];
    
    summaryLable.text = news.summary;
    summaryLable.font = [UIFont systemFontOfSize:12];
    summaryLable.textColor = [UIColor orangeColor];
    
    //有无type的图标
    NSInteger type = [news.type integerValue];
    if(type == 0)
    {
        //若type等于0；typeImageView不存在且summaryLable的坐标换为typeImageView的坐标
        typeImageView.hidden = YES;
        summaryLable.transform = CGAffineTransformMakeTranslation(-24, 0);
    }else if(type ==  1)
    {
        typeImageView.hidden = NO;
        typeImageView.image = image2;
    }else if(type == 2)
    {
        typeImageView.hidden = NO;
        typeImageView.image = imagePlay;
    }
    
    //网络加载图片
    NSURL *url = [NSURL URLWithString:news.image];
    
    //使用三方框架的方法加载网络图片
    [leftImageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"pig"]];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

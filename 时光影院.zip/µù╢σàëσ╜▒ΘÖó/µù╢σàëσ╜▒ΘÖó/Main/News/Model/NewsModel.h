//
//  NewsModel.h
//  时光影院
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsModel : NSObject

//图片
@property(nonatomic,copy)NSString *image;
//标题
@property(nonatomic,copy)NSString *title;

//详情
@property(nonatomic,copy)NSString *summary;

//类型
@property(nonatomic,strong)NSNumber *type;

@end

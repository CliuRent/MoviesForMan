//
//  LaunchController.h
//  时光影院
//
//  Created by admin on 16/9/20.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "BaseViewController.h"

@interface LaunchController : BaseViewController
{
    NSMutableArray *imageViewArray;
    
    NSInteger index;
}
@end

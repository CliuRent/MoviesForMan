//
//  GuideController.m
//  时光影院
//
//  Created by admin on 16/9/20.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "GuideController.h"
#import "BaseTabBarController.h"
#import "LaunchController.h"

@implementation GuideController

-(void)viewDidLoad{
    
    [super viewDidLoad];
    
    //创建滑动视图
    _scrollerView = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    
    //内容尺寸
    _scrollerView.contentSize = CGSizeMake(5 * KScreenWidth, KScreenHeight);
    
    //分页效果
    _scrollerView.pagingEnabled = YES;
    
    //设置代理
    _scrollerView.delegate = self;
    
    [self.view addSubview:_scrollerView];
    
    //创建图片
    [self _createImageView];
    
    //创建button
    showBotton = [UIButton buttonWithType:UIButtonTypeCustom];
    showBotton.frame = CGRectMake((KScreenWidth - 150)/2, KScreenHeight - 80, 150, 30);
    showBotton.backgroundColor = [UIColor blackColor];
    [showBotton setTitle:@"开启" forState:UIControlStateNormal];
    
    [showBotton setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    
    [showBotton addTarget:self action:@selector(bottonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [_scrollerView addSubview:showBotton];
}

//创建图片视图
-(void)_createImageView
{
    //循环创建图片视图
    for(int i = 0;i < 6;i++)
    {
        UIImageView *globalImageView= [[UIImageView alloc]initWithFrame:CGRectMake(KScreenWidth * i, 0, KScreenWidth, KScreenHeight)];
        globalImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"guide%i@2x",i+1]];
        [_scrollerView addSubview:globalImageView];
        
        //创建底部图片视图
        UIImageView *buttomImageView = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth - 173)/2 + KScreenWidth * i, KScreenHeight - 50, 173, 26)];
        buttomImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"guideProgress%i@2x",i+1]];
        [_scrollerView addSubview:buttomImageView];
    }
}

//减速完成时调用
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger index = scrollView.contentOffset.x / KScreenWidth;
    
    if(index == 4)
    {
        showBotton.hidden = NO;
    }else
    {
        showBotton.hidden = YES;
    }
}


-(void)bottonAction:(UIButton *)btn
{
    BaseTabBarController *tabBarController = [[BaseTabBarController alloc] init];
    
    self.view.window.rootViewController = tabBarController;}

@end

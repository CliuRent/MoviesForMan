//
//  TopCell.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class StarView;
@class MovieModel;
@interface TopCell : UICollectionViewCell
{
    __weak IBOutlet UIImageView *topImageView;
    __weak IBOutlet StarView *starView;
    
    __weak IBOutlet UILabel *titleLable;
    __weak IBOutlet UILabel *ratingLabel;
}
@property(nonatomic,copy)MovieModel *movie;

@end

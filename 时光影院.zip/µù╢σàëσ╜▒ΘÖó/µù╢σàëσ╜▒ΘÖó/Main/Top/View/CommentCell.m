//
//  CommentCell.m
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "CommentCell.h"
#import "MovieCommentModel.h"

@implementation CommentCell

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleDefault;
}

//确保Model一定存在
-(void)setCommentDetail:(MovieCommentModel *)commentDetail
{
    if(commentDetail)
    {
        _commentDetail = commentDetail;
        
        //填充数据
        [userImage sd_setImageWithURL:[NSURL URLWithString:commentDetail.userImage] placeholderImage:[UIImage imageNamed:@"pig"]];
        
        nickNameLabel.text = commentDetail.nickname;
        
        commentLabel.text = commentDetail.content;
        commentLabel.numberOfLines = 0;
        
        ratingLabel.text = commentDetail.rating;
        
        //设置背景的圆角弧度
        bgImageView.layer.cornerRadius = 8;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

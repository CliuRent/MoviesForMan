//
//  TopCell.m
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TopCell.h"
#import "MovieModel.h"
#import "StarView.h"

@implementation TopCell

-(void)setMovie:(MovieModel *)movie
{
    if (movie) {
        _movie = movie;
        
        //填充数据
        
        NSString *iamgeName = [movie.images objectForKey:@"medium"];
        NSURL *url = [NSURL URLWithString:iamgeName];
        //从网络上加载图片
        [topImageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"pig"]];
        
        //tileLabel
        titleLable.text = movie.title;
        titleLable.textColor = [UIColor whiteColor];
        titleLable.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
        
        //加载星星
        starView.rating = [movie.average floatValue];
        //加载评分
        ratingLabel.text = [NSString stringWithFormat:@"%.1f",[movie.average floatValue]];
    }
}

@end

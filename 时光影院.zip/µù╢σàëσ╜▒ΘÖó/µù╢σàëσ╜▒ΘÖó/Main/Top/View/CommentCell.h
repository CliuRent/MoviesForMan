//
//  CommentCell.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MovieCommentModel;
@interface CommentCell : UITableViewCell
{
    __weak IBOutlet UIImageView *userImage;
    
    __weak IBOutlet UIImageView *bgImageView;
    __weak IBOutlet UILabel *nickNameLabel;
    __weak IBOutlet UILabel *commentLabel;
    __weak IBOutlet UILabel *ratingLabel;
}
@property(nonatomic,strong)MovieCommentModel *commentDetail;
@end

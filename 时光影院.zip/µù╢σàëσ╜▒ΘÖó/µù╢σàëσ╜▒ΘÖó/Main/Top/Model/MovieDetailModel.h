//
//  MovieDetailModel.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieDetailModel : NSObject

//海报图片
@property(nonatomic,copy)NSString *image;

//电影名
@property(nonatomic,copy)NSString *titleCn;

//电影类型
@property(nonatomic,copy)NSArray *type;

//导演
@property(nonatomic,copy)NSArray *directors;

//演员
@property(nonatomic,copy)NSArray *actors;

//地区
@property(nonatomic,copy)NSString *location;

//发布时间
@property(nonatomic,copy)NSString *date;

//图片
@property(nonatomic,copy)NSArray *images;

@end

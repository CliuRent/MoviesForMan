//
//  TopDetailController.h
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "BaseViewController.h"

@interface TopDetailController : BaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property(nonatomic,strong)NSIndexPath *index;

@end

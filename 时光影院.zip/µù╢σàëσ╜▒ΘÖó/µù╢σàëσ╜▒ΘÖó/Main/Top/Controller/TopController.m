//
//  TopController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TopController.h"
#import "MovieModel.h"
#import "TopCell.h"

@interface TopController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
{
    NSMutableArray *_data;
    
    __weak IBOutlet UICollectionView *_collectionView;
}
@end

@implementation TopController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _loadDta];
    
    //集合视图的背景颜色
    _collectionView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    //设置数据源及代理对象
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    // Do any additional setup after loading the view.
}

#pragma mark  - 数据读取
-(void)_loadDta
{
    //初始化数组
    _data = [NSMutableArray array];
    
    //解析json文件
    NSDictionary *jsonDic = (NSDictionary *)[RequestData requsetDataWithFileName:top250];
    NSArray *array = [jsonDic objectForKeyedSubscript:@"subjects"];
    
    //遍历数组
    for (NSDictionary *dic in array) {
        
        //创建movieModel
        MovieModel *movie = [[MovieModel alloc]init];
        
        //读取数据
        movie.average = [[dic objectForKeyedSubscript:@"rating"]objectForKey:@"average"];
        movie.title = [dic objectForKey:@"title"];
        movie.images = [dic objectForKey:@"images"];
        
        //将movie对象添加到数组中
        [_data addObject:movie];
    }
    //刷新视图
    [_collectionView reloadData];
}
#pragma mark - 数据源及代理方法
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _data.count;
}

//创建cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    TopCell *topcell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TopCell" forIndexPath:indexPath];
    //传递数据
    topcell.movie = _data[indexPath.row];
    return topcell;
}

//单元格点击事件
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //从故事版取到控制器
    BaseViewController *topDetailController = [self.storyboard instantiateViewControllerWithIdentifier:@"TopDetailController"];
    
    //跳转后隐藏底部视图
    topDetailController.hidesBottomBarWhenPushed = YES;
    
    //push
    [self.navigationController pushViewController:topDetailController animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

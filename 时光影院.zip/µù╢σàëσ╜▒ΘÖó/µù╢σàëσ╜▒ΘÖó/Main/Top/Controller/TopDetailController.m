//
//  TopDetailController.m
//  时光影院
//
//  Created by admin on 16/8/29.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TopDetailController.h"
#import "MovieDetailModel.h"
#import "MovieCommentModel.h"
#import "CommentCell.h"

@interface TopDetailController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_DetailData;
    NSMutableArray *_CommentData;
}
@end

@implementation TopDetailController

- (void)viewDidLoad {
    [super viewDidLoad];

    //加载数据
    [self _loadDetailData];
    [self _loadCommentData];
    
    //表视图背景
    _tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    //给tableView添加滑动手势
    UISwipeGestureRecognizer *swip = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipAction)];
    
    swip.direction = UISwipeGestureRecognizerDirectionLeft;
    
    [_tableView addGestureRecognizer:swip];
    
    //设置代理及数据源方法
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    // Do any additional setup after loading the view.
}

//滑动返回上一层页面
-(void)swipAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 数据的加载
-(void)_loadDetailData
{
    //解析json文件
    NSDictionary *jsonDic = (NSDictionary *)[RequestData requsetDataWithFileName:movie_detail];
    //数组初始化
    _DetailData = [NSMutableArray array];
    
    //遍历字典
    for (NSString *key in jsonDic) {
        
        //创建Model对象
        MovieDetailModel *movieDetail = [[MovieDetailModel alloc]init];
        
        //读取数据
        movieDetail.image = [jsonDic objectForKey:@"image"];
        movieDetail.titleCn = [jsonDic objectForKey:@"titleCn"];
        movieDetail.type = jsonDic[@"type"];
        movieDetail.directors = jsonDic[@"directors"];
        movieDetail.actors = jsonDic[@"actors"];
        movieDetail.location = [jsonDic[@"release"]objectForKey:@"location"];
        movieDetail.date = [jsonDic[@"release"]objectForKey:@"date"];
        movieDetail.images = jsonDic[@"images"];
        
        //添加到数组中
        [_DetailData addObject:movieDetail];
    }
}

-(void)_loadCommentData
{
    //解析json文件
    NSDictionary *jsonDic = (NSDictionary *)[RequestData requsetDataWithFileName:movie_comment];
    NSArray *array = jsonDic[@"list"];
    
    //初始化数组
    _CommentData = [NSMutableArray array];
    
    //遍历数组,读取数据
    for (NSDictionary *dic in array) {
        
        //创建评论Model对象
        MovieCommentModel *comment = [[MovieCommentModel alloc]init];
        
        comment.userImage = dic[@"userImage"];
        comment.nickname = dic[@"nickname"];
        comment.rating = dic[@"rating"];
        comment.content = dic[@"content"];
        
        //添加到数组中
        [_CommentData addObject:comment];
    }
}

#pragma mark - 数据源及代理方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _CommentData.count + 2;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0)
    {
        //从故事版中复用单元格
        UITableViewCell *firstCell = [tableView dequeueReusableCellWithIdentifier:@"DetailCell" forIndexPath:indexPath];
        
        firstCell.backgroundColor = [UIColor clearColor];
        firstCell.selectionStyle = 0;
        //通过tag值获取视图
        
        UIImageView *posterImageView = (UIImageView *)[firstCell.contentView viewWithTag:101];
        UILabel *titleLabel = (UILabel *)[firstCell.contentView viewWithTag:102];
        UILabel *directorLabel = (UILabel *)[firstCell.contentView viewWithTag:103];
        UILabel *actorLabel = (UILabel *)[firstCell.contentView viewWithTag:104];
        UILabel *typeLabel = (UILabel *)[firstCell.contentView viewWithTag:105];
        UILabel *locationLabel = (UILabel *)[firstCell.contentView viewWithTag:106];
        UILabel *dateLabel = (UILabel *)[firstCell.contentView viewWithTag:107];
        
        //填充数据
        MovieDetailModel *detail = _DetailData[indexPath.row];
        
        //加载网络图片
        [posterImageView sd_setImageWithURL:[NSURL URLWithString:detail.image] placeholderImage:[UIImage imageNamed:@"pig"]];
        titleLabel.text = detail.titleCn;
        directorLabel.text = [NSString stringWithFormat:@"导演:%@",detail.directors[0]];
        actorLabel.text = [NSString stringWithFormat:@"主演:%@、%@、%@、%@、%@",detail.actors[0],detail.actors[1],detail.actors[2],detail.actors[3],detail.actors[4]];
        typeLabel.text = [NSString stringWithFormat:@"%@、%@、%@、%@",detail.type[0],detail.type[1],detail.type[2],detail.type[3]];
        locationLabel.text = detail.location;
        dateLabel.text = detail.date;
        return firstCell;
    }else if(indexPath.row == 1)
    {
        //从故事版直接复用
        UITableViewCell *secnodCell = [tableView dequeueReusableCellWithIdentifier:@"imageCell" forIndexPath:indexPath];
        secnodCell.backgroundColor = [UIColor clearColor];
        secnodCell.selectionStyle = 0;
        
        //通过tag 值获取视图
        UIImageView *firstImage = (UIImageView *)[secnodCell.contentView viewWithTag:108];
        UIImageView *secnodImage = (UIImageView *)[secnodCell.contentView viewWithTag:109];
        UIImageView *thirdImage = (UIImageView *)[secnodCell.contentView viewWithTag:110];
        UIImageView *fourthImage = (UIImageView *)[secnodCell.contentView viewWithTag:111];
        
        MovieDetailModel *detail = _DetailData[0];
        
        //网络加载图片
        NSArray *imageArray = detail.images;
        
        [firstImage sd_setImageWithURL:[NSURL URLWithString:imageArray[0]] placeholderImage:[UIImage imageNamed:@"pig"]];
        [secnodImage sd_setImageWithURL:[NSURL URLWithString:imageArray[1]]  placeholderImage:[UIImage imageNamed:@"pig"]];
        [thirdImage sd_setImageWithURL:[NSURL URLWithString:imageArray[2]] placeholderImage:[UIImage imageNamed:@"pig"]];
        [fourthImage sd_setImageWithURL:[NSURL URLWithString:imageArray[3]]placeholderImage:[UIImage imageNamed:@"pig"]];
        return secnodCell;
    }
    CommentCell *commentCell = [tableView dequeueReusableCellWithIdentifier:@"commentCell" forIndexPath:indexPath];
    
    //传递数据
    commentCell.commentDetail = _CommentData[indexPath.row - 2];
    return commentCell;
}
//单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0)
    {
        return 130;
    }else if (indexPath.row == 1)
    {
        return 80;
    }else if ([_index isEqual:indexPath])
    {
        //高度自适应
        MovieCommentModel *model = _CommentData[indexPath.row - 2];
        CGRect rect = [model.content boundingRectWithSize:CGSizeMake(250, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil];
        
        return rect.size.height + 40;
    }
    else return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(![self.index isEqual:indexPath])
    {
        self.index = indexPath;
        
        //刷新表视图
        [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:0];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  BaseTabBarController.m
//  时光影院
//
//  Created by admin on 16/8/25.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "BaseTabBarController.h"
#import "TabBarItem.h"
#import "BaseNavigationController.h"

@interface BaseTabBarController ()
{
    UIImageView *_selectImageView;
}
@end

@implementation BaseTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置tabBar的背景
    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tab_bg_all"]];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    //得先调用父类的方法
    [super viewWillAppear:YES];
    
    [self _createButton];
    

}

//使用按钮代替原有的UITabBarButton
-(void)_createButton
{
    for (UIView *view in self.tabBar.subviews)
    {
        
        //找到名字为UITabBarButton的视图
        Class tabBarButton = NSClassFromString(@"UITabBarButton");
        //判断是否是UITabBarButton的类的一种
        if ([view isKindOfClass:tabBarButton]) {
            //成立则从父视图中删除
            [view removeFromSuperview];
        }
    }
    
    //图片数组以及标题数组
    NSArray *imageArr = @[@"movie_cinema",@"msg_select_new",@"start_top250",@"icon_cinema",@"more_setting"];
    NSArray *titleArr = @[@"电影",@"新闻",@"top250",@"影院",@"更多"];
    
    //按钮的高  宽
    CGFloat buttonWidth = KScreenWidth / 5;
    CGFloat buttonHeight = CGRectGetHeight(self.tabBar.frame);
    
    //创建动画视图
    _selectImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, buttonWidth, buttonHeight)];
    _selectImageView.image = [UIImage imageNamed:@"selectTabbar_bg_all1"];
    [self.tabBar addSubview:_selectImageView];
    
    //创建按钮
    for(int i = 0;i < imageArr.count;i++)
    {
        //取得图片名和标题
        NSString *imageName = imageArr[i];
        NSString *title = titleArr[i];
        
        CGRect frame = CGRectMake(i * buttonWidth, 0, buttonWidth, buttonHeight);
        
        //创建butotn
        TabBarItem *item = [[TabBarItem alloc]initWithFrame:frame withImageName:imageName withTitle:title];
        //添加点击事件
        [item addTarget:self action:@selector(itemAction:) forControlEvents:UIControlEventTouchUpInside];
        item.tag = 100 + i;
        //确保第一次在item中心点上
        if(i == 0)
        {
            _selectImageView.center = item.center;
        }
        //添加
        [self.tabBar addSubview:item];
    }          
}

//点击事件实现
-(void)itemAction:(TabBarItem *)item
{
    self.selectedIndex = item.tag - 100;
    [UIView animateWithDuration:.2 animations:^{
        _selectImageView.center = item.center;
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
